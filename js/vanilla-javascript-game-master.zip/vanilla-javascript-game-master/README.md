# VanillaJS Game
Build simple games with VanillaJS

- 2048
- Snake
- Tetris
